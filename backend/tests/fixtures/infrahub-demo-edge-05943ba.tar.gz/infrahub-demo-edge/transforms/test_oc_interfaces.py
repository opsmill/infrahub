from openconfig import OCInterfaces


async def test_oc_interfaces():

    obj = OCInterfaces()
    result = await obj.transform(data={"device": []})

    assert result == {'openconfig-interfaces:interface': []}
