"""Replacement for Makefile."""
import os
import sys
import glob
from distutils.util import strtobool
from datetime import datetime

from typing import Tuple

from invoke import task, Context  # type: ignore

def git_info(context: Context) -> Tuple[str, str]:
    """Return the name of the current branch and hash of the current commit."""
    branch_name = context.run("git rev-parse --abbrev-ref HEAD", hide=True, pty=False)
    hash = context.run("git rev-parse --short HEAD", hide=True, pty=False)
    return branch_name.stdout.strip(), hash.stdout.strip()

@task
def build_test_package(context):
    """ddd
    """
    # pty is set to true to properly run the docker commands due to the invocation process of docker
    # https://docs.pyinvoke.org/en/latest/api/runners.html - Search for pty for more information
    # Install python module
    exec_cmd = "pytest --cov=diffsync --cov-config pyproject.toml --cov-report html --cov-report term -vv"
    result = context.run(exec_cmd, pty=True)
